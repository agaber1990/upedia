<?php
    return [    "certificate::Generate Certificate" => "certificate::Generate Certificate",
        ]
?>