<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmModuleLink extends Model
{
   //
}
