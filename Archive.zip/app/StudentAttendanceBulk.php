<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentAttendanceBulk extends Model
{
    protected $guarded  = ['id'];
}