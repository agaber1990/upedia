<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmCountry extends Model
{
    protected $table = 'countries';
}
