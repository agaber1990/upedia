<?php

namespace Database\Seeders\Student;

use App\SmStudent;
use Illuminate\Database\Seeder;

class SmStudentsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run($school_id, $academic_id, $count = 5)
    {

    }
}
