<?php

namespace Database\Seeders;

use App\SmAboutPage;
use Illuminate\Database\Seeder;

class sm_about_pagesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    { 
    }
}
