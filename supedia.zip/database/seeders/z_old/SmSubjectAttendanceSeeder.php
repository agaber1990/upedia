<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\SmSubjectAttendance;
use App\SmStudent;;
class SmSubjectAttendanceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
    }
}
