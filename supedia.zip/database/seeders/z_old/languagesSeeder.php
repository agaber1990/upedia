<?php

namespace Database\Seeders;

use App\SmLanguage;
use Illuminate\Database\Seeder;
class languagesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        // $store = new SmLanguage();
        // $store->language_name ='English';
        // $store->native ='English';
        // $store->language_universal ='en';
        // $store->active_status =1;
        // $store->save();
    }
}
