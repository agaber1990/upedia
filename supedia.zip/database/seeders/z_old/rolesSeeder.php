<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\RolePermission\Entities\InfixRole;
use App\Role;

class rolesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        // InfixRole::query()->truncate();

        // DB::table('roles')->insert([
        //     [
        //         'name' => 'Super admin',    //      1
        //         'type' => 'System',
        //         'school_id' => 1
        //     ],
        //     [
        //         'name' => 'Student',    //      2
        //         'type' => 'System',
        //         'school_id' => 1
        //     ],
        //     [
        //         'name' => 'Parents',    //      3
        //         'type' => 'System',
        //         'school_id' => 1
        //     ],
        //     [
        //         'name' => 'Teacher',    //      4
        //         'type' => 'System',
        //         'school_id' => 1
        //     ],
        //     [
        //         'name' => 'Admin',    //      5
        //         'type' => 'System',
        //         'school_id' => 1
        //     ],
        //     [
        //         'name' => 'Accountant',    //      6
        //         'type' => 'System',
        //         'school_id' => 1
        //     ],
        //     [
        //         'name' => 'Receptionist',    //      7
        //         'type' => 'System',
        //         'school_id' => 1
        //     ],
        //     [
        //         'name' => 'Librarian',    //      8
        //         'type' => 'System',
        //         'school_id' => 1
        //     ],
        //     [
        //         'name' => 'Driver',    //      9
        //         'type' => 'System',
        //         'school_id' => 1
        //     ],
        //     [
        //         'name' => 'Customer',    //      10
        //         'type' => 'System',
        //         'school_id' => 1
        //     ]

        // ]);


    }
}
