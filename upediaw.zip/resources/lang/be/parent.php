<?php 
return [
    'parent_dashboard'=>'Parent Dashboard',
    'my_children'=>'My Children',
    'calendar'=>'Calendar',
    'total_subject'=>'Total Subject',
    'total_notice'=>'Total Notice',
    'total_exam'=>'Total Exam',
    'total_online_exam'=>'Total Online Exam',
    'total_teachers'=>'Total Teachers',
    'total_issued_book'=>'Total Issued Book',
    'total_pending_home_work'=>'Total Pending Homework',
    'total_attendance_in_current_month'=>'Total Attendance In Current Month',
    'notice'=>'Notice',
    'exam'=>'Exam',
    'online_exam'=>'Online Exam',
    'teachers'=>'Teachers',
    'issued_book'=>'Issued Book',
    'pending_home_work'=>'Pending Homework',
    'attendance_in_current_month'=>'Attendance In Current Month',
    'parent_dashboard'=>'Parent Dashboard',
    'parent_id'=>'Parent ID',
    
];